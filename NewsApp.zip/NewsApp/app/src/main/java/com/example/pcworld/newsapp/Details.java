package com.example.pcworld.newsapp;


public class Details {
    private String sectionName;
    private String titleName;
    private String url;
    private String authorName;
    private String Date;

    public Details(String sName, String tName, String mUrl, String AName, String D) {
        sectionName = sName;
        titleName = tName;
        url = mUrl;
        authorName = AName;
        Date = D;
    }


    public String getSectionName() {
        return sectionName;
    }

    public String getTitleName() {
        return titleName;
    }


    public String getUrl() {
        return url;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getDate() {
        return Date;
    }
}
