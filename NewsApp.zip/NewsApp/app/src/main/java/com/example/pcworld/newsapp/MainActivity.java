package com.example.pcworld.newsapp;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<Details>> {
    private static final String REQUEST_URL = "https://content.guardianapis.com/search?show-tags=contributor&q=color%20folwer&api-key=4b102257-1b8a-427e-ad36-077001bde55f";
    private ListView listView1;
    public static TextView errorConnection;
    private static final int LOADER_ID = 1;
    private AdapterApp adapter;
    public static ConnectivityManager connectivityManager;
    public static NetworkInfo networkInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView1 = (ListView) findViewById(R.id.listview);
        errorConnection = (TextView) findViewById(R.id.error);
        listView1.setEmptyView(errorConnection);
        ArrayList<Details> arraylist = new ArrayList<Details>();
        adapter = new AdapterApp(this, arraylist);
        listView1.setAdapter(adapter);
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = connectivityManager.getActiveNetworkInfo();

        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Details details = adapter.getItem(position);
                String getUrl = details.getUrl();
                Uri uri = Uri.parse(getUrl);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(uri);
                startActivity(intent);
            }
        });

        if (networkInfo != null && networkInfo.isConnected()) {
            getLoaderManager().initLoader(LOADER_ID, null, this);
        } else {
            errorConnection.setText("Internet Connection Error");
        }
    }


    @Override
    public Loader<ArrayList<Details>> onCreateLoader(int id, Bundle args) {
        return new LoaderApp(this, REQUEST_URL);
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<Details>> loader, ArrayList<Details> data) {
        adapter.clear();
        errorConnection.setText("Internet Connection Error");
        if (loader != null && !data.isEmpty()) {
            adapter.addAll(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<ArrayList<Details>> loader) {
        adapter.clear();
    }
}
