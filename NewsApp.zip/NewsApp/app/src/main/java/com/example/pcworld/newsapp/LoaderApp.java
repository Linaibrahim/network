package com.example.pcworld.newsapp;


import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.ArrayList;

import static com.example.pcworld.newsapp.MainActivity.errorConnection;
import static com.example.pcworld.newsapp.QueryDisplay.fetchData;

public class LoaderApp extends AsyncTaskLoader<ArrayList<Details>> {
    private String uri;
    ArrayList<Details> mLoader = new ArrayList<>();

    public LoaderApp(Context context, String mUri) {
        super(context);
        uri = mUri;
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }

    @Override
    public ArrayList<Details> loadInBackground() {
        if (uri == null) {
            errorConnection.setText("Internet Connection Error");
            return null;
        }
        mLoader = fetchData(uri);
        return mLoader;
    }
}
