package com.example.pcworld.newsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterApp extends ArrayAdapter<Details> {

    public AdapterApp(Context context, ArrayList<Details> list) {
        super(context, 0, list);
    }

    @Override
    public View getView(int position, View comeView, ViewGroup parent) {
        View view = comeView;
        if (view == null) {
            LayoutInflater layoutInflater = null;
            view = layoutInflater.from(getContext()).inflate(R.layout.item_design, null);
        }
        Details dataPosition = getItem(position);
        TextView sectionName = (TextView) view.findViewById(R.id.nameSection);
        TextView titleName = (TextView) view.findViewById(R.id.nameTitle);
        TextView authName = (TextView) view.findViewById(R.id.nameAuthor);
        TextView date = (TextView) view.findViewById(R.id.Date);
        sectionName.setText("Section: ");
        sectionName.append(dataPosition.getSectionName());
        titleName.setText("Title: ");
        titleName.append(dataPosition.getTitleName());
        authName.setText("Author: ");
        authName.append(dataPosition.getAuthorName());
        date.setText("Date: ");
        date.append(dataPosition.getDate());
        return view;
    }
}