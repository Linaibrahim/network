package com.example.pcworld.newsapp;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import static com.example.pcworld.newsapp.MainActivity.errorConnection;

public class QueryDisplay {
    private QueryDisplay() {
    }

    public static ArrayList<Details> fetchData(String requestUrl) {
        URL url = createURL(requestUrl);
        String jsonResponse = null;
        try {
            jsonResponse = makeHTTPRequest(url);
        } catch (IOException e) {
            Log.i(QueryDisplay.class.getSimpleName(), "Error in input stream", e);
        }
        ArrayList<Details> arrayList = extractQuery(jsonResponse);
        return arrayList;
    }

    private static URL createURL(String stringUrl) {
        URL url = null;
        try {
            url = new URL(stringUrl);

        } catch (MalformedURLException e) {
            Log.i(QueryDisplay.class.getSimpleName(), "Error in function createURL ", e);
        }
        return url;
    }

    private static String makeHTTPRequest(URL url) throws IOException {
        String jsonResponse = "";
        if (url == null) {
            return jsonResponse;
        }
        HttpURLConnection URLConnection = null;
        InputStream inputStream = null;
        try {
            URLConnection = (HttpURLConnection) url.openConnection();
            URLConnection.setReadTimeout(10000);
            URLConnection.setConnectTimeout(15000);
            URLConnection.setRequestMethod("GET");
            URLConnection.connect();

            if (URLConnection.getResponseCode() == 200) {
                inputStream = URLConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } else {
                errorConnection.setText("Internet Connection Error");
                Log.i(QueryDisplay.class.getSimpleName(), "Error response " + URLConnection.getResponseCode());
            }
        } catch (IOException e) {
            Log.i(QueryDisplay.class.getSimpleName(), "Problem retrieving the data JSON results.", e);
        } finally {
            if (URLConnection != null) {
                URLConnection.disconnect();
            }
            if (inputStream != null) {
                inputStream.close();
            }
        }
        return jsonResponse;
    }


    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder finalSteps = new StringBuilder();
        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String step = bufferedReader.readLine();
            while (step != null) {
                finalSteps.append(step);
                step = bufferedReader.readLine();
            }
        }
        return finalSteps.toString();
    }

    public static ArrayList<Details> extractQuery(String detailsJSON) {
        ArrayList<Details> arrayListDetails = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(detailsJSON);
            JSONObject bigRoot = jsonObject.getJSONObject("response");
            JSONArray childRoot = bigRoot.getJSONArray("results");
            boolean flagName;
            boolean flagDate;
            for (int i = 0; i < childRoot.length(); i++) {
                flagName = false;
                flagDate = false;
                String fullName = "";
                String date = "";
                JSONObject DetailsData = childRoot.getJSONObject(i);
                String section = DetailsData.getString("sectionName");
                String title = DetailsData.getString("webTitle");
                String urlparss = DetailsData.getString("webUrl");
                Log.i(QueryDisplay.class.getSimpleName(), "json final data:" + section + "\n" + title + "\n");
                JSONArray tagsDetails = DetailsData.getJSONArray("tags");
                for (int j = 0; j < tagsDetails.length(); j++) {
                    JSONObject tagsChild = tagsDetails.getJSONObject(j);
                    String firstName = tagsChild.getString("firstName");
                    String lastName = tagsChild.getString("lastName");
                    fullName = firstName + " ".concat(lastName);
                    flagName = true;
                }
                if (DetailsData.getString("webPublicationDate") != null) {
                    date = DetailsData.getString("webPublicationDate");
                    flagDate = true;
                }
                if (flagName && flagDate) {
                    arrayListDetails.add(new Details(section, title, urlparss, fullName, date));
                } else if (flagName && !flagDate) {
                    date = "Not found";
                    arrayListDetails.add(new Details(section, title, urlparss, fullName, date));
                } else {
                    fullName = "Not Found";
                    date = "Not Found";
                    arrayListDetails.add(new Details(section, title, urlparss, fullName, date));
                }
            }
        } catch (JSONException e) {
            Log.i(QueryDisplay.class.getSimpleName(), "Problem  JSON ", e);
        }
        return arrayListDetails;
    }
}
